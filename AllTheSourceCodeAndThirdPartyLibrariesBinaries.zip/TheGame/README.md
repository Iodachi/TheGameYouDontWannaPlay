the game you don't want to play

Abstract:
A Warrior is trapped in a tower, he has to ‘explore’ the tower to find the way out. The tower has multiple levels and each floor is a maze with walls, doors, and monsters and items all over the place. On the journey, he will meet different monsters and he has to beat them while finding treasures, equipments to level him up, as well as finding keys to unlock the door to enter certain rooms or floors. Ultimately，he will reach the top floor, beat the boss and escape from the maze, or, he may find himself trapped in a place because the lack of keys, or beaten up by a monster.

Player:
Player can use arrow keys to control the character to explore the map. Player has certain health, attributes such as damage and defence, with weapons such as and swords and arrows, and outfits such as armour and rings to gain him a boost towards certain attributes, his inventory will allow him to carry gold which allows trading or buying items from the shop, and consumable items such as keys and health potions. A experience system is also considered to be introduced, when player kills monsters they gain xp and they could level up to become more powerful.

Monsters:
Similar to player, they also have health and damage, etc. Monsters are not moveable and take one grid on the board. Player will only interact with monster when they move to that grid. Monsters appear randomly across the map and could possibly drop items when being killed. Monsters will get stronger and stronger when going to higher levels of the tower, bringing more challenges to the player.

Certain algorithms will be introduced to compute the health consumed when attacking monsters, both player’s damage and defence will be taken into consideration, and possibly the attack speed as well. For example the monsters’ damage may increase over time meaning the higher player’s damage is, the quicker the player kills a monster, and less health will be consumed.

Items:
There will be either consumable items such as health potions, keys and gold, or non-consumables such as swords and shields for player to equip, the items will randomly appear on the map, or drop after killing a monster, player can also use gold to buy items in a shop.

Map:
Only one floor at a time will be shown to the player, the whole board will be seen as a 2D array with walls, empty spaces, water, lava and so on. Monsters and items will only appear on empty spaces, players can only move on empty spaces as well, unless, he has special items such as key, which can be used for opening the door. There will be “rooms” on the map that can only be accessed after using a key. There will be ladders that connect the floors of the tower, player will enter the next floor when step on the ladder.

Although The game looks simple, it involves a lot of thinking, and any thoughtless choice could lead to the failure of the game. We plan to design some fun props which will make the the game more interesting. We also thought about more features such as a bomb to blow up special breakable-walls, and more bosses in certain floors, and beating them would gain player special items, these could be added in the future if we have time.
