package commonPackage.usefor.test;

public interface MockConsumableItem {
	public abstract void use(RealPlayer player);
}
