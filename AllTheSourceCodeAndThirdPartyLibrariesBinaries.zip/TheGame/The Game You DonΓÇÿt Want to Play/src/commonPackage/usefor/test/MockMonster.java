package commonPackage.usefor.test;

public interface MockMonster {

}
