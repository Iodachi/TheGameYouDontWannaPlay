package commonPackage.usefor.test;

public interface MockShop {

}
