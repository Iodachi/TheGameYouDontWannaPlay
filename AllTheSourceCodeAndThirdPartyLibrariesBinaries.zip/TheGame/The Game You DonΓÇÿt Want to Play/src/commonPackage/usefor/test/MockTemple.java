package commonPackage.usefor.test;

public interface MockTemple {

}
