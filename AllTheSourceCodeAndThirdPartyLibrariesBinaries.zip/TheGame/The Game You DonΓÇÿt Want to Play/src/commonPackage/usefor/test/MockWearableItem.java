package commonPackage.usefor.test;

public interface MockWearableItem {
	public String getName();
}
