package commonPackage.usefor.test;

public interface MockWiseMan {

}
