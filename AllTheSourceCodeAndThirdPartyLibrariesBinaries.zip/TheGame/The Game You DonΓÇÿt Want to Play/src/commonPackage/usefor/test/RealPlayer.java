package commonPackage.usefor.test;

public interface RealPlayer {
	public void setHealth(int health);

	public int getHealth();

	public void setDamage(int damage) ;

	public int getDamage();
	public void setDefence(int defence);
	public int getDefence();

	public void setGold(int gold);

	public int getGold();
	public int getSpeed();

	public void setSpeed(int speed);
}
